"""Core configuration package."""
